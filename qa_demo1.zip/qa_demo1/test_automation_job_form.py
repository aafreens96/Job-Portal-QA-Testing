import time
import pytest
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import os


# Configure Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)


# Setup WebDriver with Debugging Options
def setup_driver(debug=False):
    options = Options()
    # if not debug:
    options.add_argument("--headless")  # Run in headless mode only if not debugging
    options.add_argument("--disable-gpu")
    options.add_argument("--start-maximized")  # Start browser maximized
    options.set_capability("goog:loggingPrefs", {"browser": "ALL"})  # Enable console logs

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    driver.get("https://demoqa.com/automation-practice-form")
    driver.execute_script("document.body.style.zoom='20%'")  # Zoom in to escape ads
    logger.info("Opened the job application form page and zoomed in.")
    return driver


# Function to Take Screenshot on Failure
def take_screenshot(driver, test_name):
    screenshot_path = f"{test_name}.png"
    driver.save_screenshot(screenshot_path)
    logger.error(f"Screenshot saved: {screenshot_path}")


# Function to attempt an action up to 5 times
def attempt_action(driver, action, description):
    for attempt in range(5):
        try:
            action()
            return  # Success
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1}: {description} failed. Retrying...")
            time.sleep(1)  # Short delay before retry
    logger.error(f"Failed after 5 attempts: {description}")
    raise Exception(f"Unable to complete: {description}")


# Test Case 1: Valid Form Submission
def test_valid_form_submission():
    driver = setup_driver(debug=True)
    try:
        logger.info("Starting test: Valid Form Submission")

        attempt_action(driver, lambda: driver.find_element(By.ID, "firstName").send_keys("John"), "Entering First Name")
        attempt_action(driver, lambda: driver.find_element(By.ID, "lastName").send_keys("Doe"), "Entering Last Name")
        attempt_action(driver, lambda: driver.find_element(By.ID, "userEmail").send_keys("john.doe@example.com"), "Entering Email")
        attempt_action(driver, lambda: driver.find_element(By.CSS_SELECTOR, "label[for='gender-radio-1']").click(), "Selecting Gender")
        attempt_action(driver, lambda: driver.find_element(By.ID, "userNumber").send_keys("9876543210"), "Entering Mobile Number")

        # Date of Birth Handling
        attempt_action(driver, lambda: driver.find_element(By.ID, "dateOfBirthInput").clear(), "Clearing DOB")
        attempt_action(driver, lambda: driver.find_element(By.ID, "dateOfBirthInput").send_keys("15 Jan 1995"), "Entering DOB")
        attempt_action(driver, lambda: driver.find_element(By.ID, "dateOfBirthInput").send_keys(Keys.ESCAPE), "Closing DOB Picker")

        # Enter Subject
        attempt_action(driver, lambda: driver.find_element(By.ID, "subjectsInput").send_keys("Maths"), "Entering Subject")
        attempt_action(driver, lambda: driver.find_element(By.ID, "subjectsInput").send_keys(Keys.TAB), "Selecting Subject")

        # Select Hobbies by clicking their labels instead of the checkbox input
        attempt_action(driver, lambda: driver.find_element(By.CSS_SELECTOR, "label[for='hobbies-checkbox-1']").click(),
                       "Selecting Hobby - Sports")
        attempt_action(driver, lambda: driver.find_element(By.CSS_SELECTOR, "label[for='hobbies-checkbox-2']").click(),
                       "Selecting Hobby - Reading")
        # # File Upload Handling
        # upload_input = driver.find_element(By.ID, "uploadPicture")
        # logger.info("Waiting for user to select an image...")
        # time.sleep(10)  # Give the user time to select an image
        # if os.path.exists("sample-image.jpg"):  # Check if user has selected an image
        #     attempt_action(driver, lambda: upload_input.send_keys(os.path.abspath("sample-image.jpg")), "Uploading Image")
        # else:
        #     logger.warning("No image selected. Skipping file upload.")

        # Enter Current Address
        attempt_action(driver, lambda: driver.find_element(By.ID, "currentAddress").send_keys("123, Main Street, New York, USA"), "Entering Address")

        # Select State and City
        attempt_action(driver, lambda: driver.find_element(By.ID, "react-select-3-input").send_keys("NCR"), "Selecting State")
        attempt_action(driver, lambda: driver.find_element(By.ID, "react-select-3-input").send_keys(Keys.ENTER), "Confirming State")
        time.sleep(2)
        attempt_action(driver, lambda: driver.find_element(By.ID, "react-select-4-input").send_keys("Delhi"), "Selecting City")
        attempt_action(driver, lambda: driver.find_element(By.ID, "react-select-4-input").send_keys(Keys.ENTER), "Confirming City")

        # Submit the form
        attempt_action(driver, lambda: driver.execute_script("arguments[0].click();", driver.find_element(By.ID, "submit")), "Clicking Submit Button")

        # Wait for the modal to appear
        time.sleep(3)
        modal_title = driver.find_element(By.ID, "example-modal-sizes-title-lg").text
        assert modal_title == "Thanks for submitting the form", "Form submission failed or modal not displayed"

        logger.info("Test Passed: Valid Form Submission")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        take_screenshot(driver, "test_valid_form_submission")
    finally:
        driver.quit()


# Test Case 2: Mandatory Fields Left Blank
def test_mandatory_fields_blank():
    driver = setup_driver(debug=True)
    try:
        logger.info("Starting test: Mandatory Fields Blank")

        # Click submit without entering any mandatory fields
        attempt_action(driver, lambda: driver.find_element(By.ID, "submit").click(), "Clicking Submit Button")
        time.sleep(2)  # Wait for validation to trigger

        # Check if form validation triggered (class 'was-validated' should be added)
        form = driver.find_element(By.ID, "userForm")
        assert "was-validated" in form.get_attribute("class"), "Validation error not triggered for missing fields"

        logger.info("Test Passed: Mandatory Fields Blank")
    except Exception as e:
        logger.error(f"Test failed: {e}")
    finally:
        driver.quit()


# Test Case 3: Invalid Email Format Validation
def test_invalid_email_format():
    driver = setup_driver(debug=True)
    try:
        logger.info("Starting test: Invalid Email Format")
        attempt_action(driver, lambda: driver.find_element(By.ID, "firstName").send_keys("John"), "Entering First Name")
        attempt_action(driver, lambda: driver.find_element(By.ID, "lastName").send_keys("Doe"), "Entering Last Name")
        attempt_action(driver, lambda: driver.find_element(By.CSS_SELECTOR, "label[for='gender-radio-1']").click(), "Selecting Gender")
        attempt_action(driver, lambda: driver.find_element(By.ID, "userEmail").send_keys("invalid-email"), "Entering Invalid Email")
        attempt_action(driver, lambda: driver.find_element(By.ID, "userNumber").send_keys("9876543210"), "Entering Mobile Number")
        attempt_action(driver, lambda: driver.execute_script("arguments[0].click();", driver.find_element(By.ID, "submit")), "Clicking Submit Button")

        form = driver.find_element(By.ID, "userForm")
        assert "was-validated" in form.get_attribute("class"), "Invalid email was accepted"
        logger.info("Test Passed: Invalid Email Format")
    except Exception as e:
        logger.error(f"Test failed: {e}")
        take_screenshot(driver, "test_invalid_email_format")
    finally:
        driver.quit()


if __name__ == "__main__":
    logger.info("Starting test execution...")
    # test_valid_form_submission()
    # test_mandatory_fields_blank()
    # test_invalid_email_format()
    pytest.main(["--html=report.html", "--self-contained-html"])